using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ClaimSystem.Data;
using ClaimSystem.Models;
using System.Linq;
using System.Threading.Tasks;

namespace ClaimSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        // This handles both LecturerView and SubmitClaim
        [HttpGet]
        public IActionResult LecturerView()
        {
            return View("SubmitClaim"); // Return the SubmitClaim view
        }

        [HttpGet]
        public IActionResult SubmitClaim()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SubmitClaim(Claim claim)
        {
            if (ModelState.IsValid)
            {
                claim.Status = "Pending";
                _context.Claims.Add(claim);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Claim submitted successfully!";
                return RedirectToAction(nameof(TrackClaims));
            }
            return View(claim);
        }

        [HttpGet]
        public async Task<IActionResult> TrackClaims()
        {
            var claims = await _context.Claims
                .OrderByDescending(c => c.Date)
                .ToListAsync();
            return View(claims);
        }

        // This handles both ManagerView and ManageClaims
        [HttpGet]
        public IActionResult ManagerView()
        {
            return RedirectToAction(nameof(ManageClaims)); // Redirect to ManageClaims
        }

        [HttpGet]
        public async Task<IActionResult> ManageClaims()
        {
            var pendingClaims = await _context.Claims
                .Where(c => c.Status == "Pending")
                .OrderBy(c => c.Date)
                .ToListAsync();
            return View(pendingClaims);
        }

        // Add HR View for reports
        [HttpGet]
        public async Task<IActionResult> HRView()
        {
            var allClaims = await _context.Claims
                .OrderByDescending(c => c.Date)
                .ToListAsync();
            return View("HRReports", allClaims); // Use HRReports view
        }

        [HttpGet]
        public async Task<IActionResult> HRReports()
        {
            var allClaims = await _context.Claims
                .OrderByDescending(c => c.Date)
                .ToListAsync();
            return View(allClaims);
        }

        [HttpPost]
        public async Task<IActionResult> ApproveClaim(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim != null)
            {
                claim.Status = "Approved";
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = $"Claim from {claim.LecturerName} has been approved.";
            }
            return RedirectToAction(nameof(ManageClaims));
        }

        [HttpPost]
        public async Task<IActionResult> RejectClaim(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim != null)
            {
                claim.Status = "Rejected";
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = $"Claim from {claim.LecturerName} has been rejected.";
            }
            return RedirectToAction(nameof(ManageClaims));
        }

        [HttpPost]
        public IActionResult CalculateTotal(double hours, double hourlyRate)
        {
            var total = hours * hourlyRate;
            return Json(new { total = total.ToString("F2") });
        }

        // Generate report data for HR
        [HttpGet]
        public async Task<IActionResult> GenerateReport()
        {
            var claims = await _context.Claims.ToListAsync();
            var reportData = new
            {
                TotalClaims = claims.Count,
                ApprovedClaims = claims.Count(c => c.Status == "Approved"),
                PendingClaims = claims.Count(c => c.Status == "Pending"),
                RejectedClaims = claims.Count(c => c.Status == "Rejected"),
                TotalAmount = claims.Where(c => c.Status == "Approved").Sum(c => c.TotalAmount)
            };
            return Json(reportData);
        }
    }
}