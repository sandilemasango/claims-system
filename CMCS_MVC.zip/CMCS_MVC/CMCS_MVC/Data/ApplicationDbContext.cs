﻿using Microsoft.EntityFrameworkCore;
using ClaimSystem.Models;

namespace ClaimSystem.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Claim> Claims { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure the table name if needed
            modelBuilder.Entity<Claim>().ToTable("Claims");

            // Seed sample data - only assign values to properties that can be set
            modelBuilder.Entity<Claim>().HasData(
                new Claim
                {
                    ClaimId = 1,
                    LecturerName = "Dr. Smith",
                    Date = DateTime.Now.AddDays(-2), // This is DateTime, not string
                    Hours = 40,
                    HourlyRate = 75,
                    Status = "Approved",
                    Notes = "Regular teaching hours for October",
                    Documents = "syllabus.pdf"
                    // Don't set TotalAmount, StatusColor, or DocumentInfo - they're calculated properties
                },
                new Claim
                {
                    ClaimId = 2,
                    LecturerName = "Prof. Johnson",
                    Date = DateTime.Now.AddDays(-1), // This is DateTime, not string
                    Hours = 35,
                    HourlyRate = 80,
                    Status = "Pending",
                    Notes = "Additional workshop preparation",
                    Documents = "workshop_plan.docx"
                    // Don't set TotalAmount, StatusColor, or DocumentInfo - they're calculated properties
                }
            );
        }
    }
}