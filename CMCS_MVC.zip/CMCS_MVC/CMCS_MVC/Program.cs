using Microsoft.EntityFrameworkCore;
using ClaimSystem.Data;
using ClaimSystem.Models;  // Add this using directive

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllersWithViews();

// Use In-Memory Database for development
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseInMemoryDatabase("ClaimSystemDb"));

var app = builder.Build();

// Configure the HTTP request pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
else
{
    app.UseDeveloperExceptionPage();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Seed the in-memory database
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try
    {
        var context = services.GetRequiredService<ApplicationDbContext>();

        // Add sample data to in-memory database
        if (!context.Claims.Any())
        {
            context.Claims.Add(new Claim
            {
                ClaimId = 1,
                LecturerName = "Dr. Smith",
                Date = DateTime.Now.AddDays(-2),
                Hours = 40,
                HourlyRate = 75,
                Status = "Approved",
                Notes = "Regular teaching hours for October",
                Documents = "syllabus.pdf"
            });

            context.Claims.Add(new Claim
            {
                ClaimId = 2,
                LecturerName = "Prof. Johnson",
                Date = DateTime.Now.AddDays(-1),
                Hours = 35,
                HourlyRate = 80,
                Status = "Pending",
                Notes = "Additional workshop preparation",
                Documents = "workshop_plan.docx"
            });

            context.SaveChanges();
        }
    }
    catch (Exception ex)
    {
        var logger = services.GetRequiredService<ILogger<Program>>();
        logger.LogError(ex, "An error occurred seeding the database.");
    }
}

app.Run();