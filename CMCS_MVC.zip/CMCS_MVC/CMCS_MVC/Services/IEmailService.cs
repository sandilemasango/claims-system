﻿namespace ClaimSystem.Services
{
    public interface IEmailService
    {
        Task SendClaimStatusNotificationAsync(string email, string lecturerName, string claimStatus, double amount);
        Task SendApprovalNotificationAsync(string email, string lecturerName, string claimId);
    }
}