﻿using ClaimSystem.Models;

namespace ClaimSystem.Services
{
    public interface IReportService
    {
        byte[] GenerateClaimsReport(List<Claim> claims);
        byte[] GeneratePaymentReport(List<Claim> claims);
    }
}