﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ClaimSystem.Models
{
    public class Claim
    {
        public int ClaimId { get; set; }

        [Required]
        public string LecturerName { get; set; } = string.Empty;

        [Required]
        [DataType(DataType.Date)]
        public DateTime Date { get; set; } = DateTime.Now;  // This is correct - DateTime to DateTime

        [Required]
        [Range(0.1, double.MaxValue, ErrorMessage = "Hours must be greater than 0")]
        public double Hours { get; set; }

        [Required]
        [Range(0.1, double.MaxValue, ErrorMessage = "Hourly rate must be greater than 0")]
        public double HourlyRate { get; set; }

        public double TotalAmount => Hours * HourlyRate;

        [Required]
        public string Status { get; set; } = "Pending";

        public string StatusColor => Status switch
        {
            "Approved" => "#27ae60",
            "Rejected" => "#e74c3c",
            _ => "#f39c12"
        };

        public string Notes { get; set; } = string.Empty;

        public string Documents { get; set; } = string.Empty;

        public string DocumentInfo => !string.IsNullOrEmpty(Documents) && Documents != "None" ?
            $"📎 {Documents}" : "No documents";
    }
}