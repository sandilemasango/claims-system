﻿using FluentValidation;
using ClaimSystem.Models;

namespace ClaimSystem.Validators
{
    public class ClaimValidator : AbstractValidator<Claim>
    {
        public ClaimValidator()
        {
            RuleFor(x => x.LecturerName)
                .NotEmpty().WithMessage("Lecturer name is required")
                .Length(2, 100).WithMessage("Lecturer name must be between 2 and 100 characters");

            RuleFor(x => x.Hours)
                .GreaterThan(0).WithMessage("Hours must be greater than 0")
                .LessThanOrEqualTo(80).WithMessage("Hours cannot exceed 80 per claim");

            RuleFor(x => x.HourlyRate)
                .GreaterThan(0).WithMessage("Hourly rate must be greater than 0")
                .LessThanOrEqualTo(200).WithMessage("Hourly rate cannot exceed $200");

            RuleFor(x => x.Notes)
                .MaximumLength(500).WithMessage("Notes cannot exceed 500 characters");

            RuleFor(x => x.Date)
                .NotEmpty().WithMessage("Date is required");
        }
    }
}